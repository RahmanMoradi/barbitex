<?php

namespace App\Models\Traid\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MarketHistory extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
}
