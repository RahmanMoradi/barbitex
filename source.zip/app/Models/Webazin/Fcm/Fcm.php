<?php

namespace App\Models\Webazin\Fcm;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fcm extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
}
