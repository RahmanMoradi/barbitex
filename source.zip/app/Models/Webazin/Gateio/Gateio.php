<?php

namespace App\Models\Webazin\Gateio;

use Illuminate\Support\Facades\Http;
use Whoops\Exception\ErrorException;

class Gateio
{
    private static $defaultConfiguration;

    /**
     * Access token for OAuth/Bearer authentication
     *
     * @var string
     */
    protected $accessToken = '';

    /**
     * Username for HTTP basic authentication
     *
     * @var string
     */
    protected $username = '';

    /**
     * Password for HTTP basic authentication
     *
     * @var string
     */
    protected $password = '';

    /**
     * The host
     *
     * @var string
     */
    protected $host = 'https://api.gateio.ws/api/v4/';

    /**
     * User agent of the HTTP request, set to "OpenAPI-Generator/{version}/PHP" by default
     *
     * @var string
     */
    protected $userAgent = 'OpenAPI-Generator/5.24.0/PHP';

    /**
     * Debug switch (default set to false)
     *
     * @var bool
     */
    protected $debug = false;

    /**
     * Debug file location (log to STDOUT by default)
     *
     * @var string
     */
    protected $debugFile = 'php://output';

    /**
     * Debug file location (log to STDOUT by default)
     *
     * @var string
     */
    protected $tempFolderPath;

    /**
     * API key
     *
     * @var string
     */
    protected $key = "da38454e50c605d4ba06b1688aabe252";

    /**
     * API secret
     *
     * @var string
     */
    protected $secret = "eb89777574e51a90c3159bcf2fd2633a70ca9233bd15d457df16b96f6b4d6c81";

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->tempFolderPath = sys_get_temp_dir();
    }

    /**
     * Sets the API key for GateAPIv4
     *
     * @param string $key API key for GateAPIv4
     *
     * @return $this
     */
    public function setKey($key)
    {
        $this->key = $key;
        return $this;
    }

    /**
     * Gets the API key for GateAPIv4
     *
     * @return string API secret for GateAPIv4
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * Sets the API secret for GateAPIv4
     *
     * @param string $secret API secret for GateAPIv4
     *
     * @return $this
     */
    public function setSecret($secret)
    {
        $this->secret = $secret;
        return $this;
    }

    /**
     * Gets the API secret for GateAPIv4
     *
     * @return string API secret for GateAPIv4
     */
    public function getSecret()
    {
        return $this->secret;
    }

    /**
     * Sets the access token for OAuth
     *
     * @param string $accessToken Token for OAuth
     *
     * @return $this
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;
        return $this;
    }

    /**
     * Gets the access token for OAuth
     *
     * @return string Access token for OAuth
     */
    public function getAccessToken()
    {
        return $this->accessToken;
    }

    /**
     * Sets the username for HTTP basic authentication
     *
     * @param string $username Username for HTTP basic authentication
     *
     * @return $this
     */
    public function setUsername($username)
    {
        $this->username = $username;
        return $this;
    }

    /**
     * Gets the username for HTTP basic authentication
     *
     * @return string Username for HTTP basic authentication
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Sets the password for HTTP basic authentication
     *
     * @param string $password Password for HTTP basic authentication
     *
     * @return $this
     */
    public function setPassword($password)
    {
        $this->password = $password;
        return $this;
    }

    /**
     * Gets the password for HTTP basic authentication
     *
     * @return string Password for HTTP basic authentication
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Sets the host
     *
     * @param string $host Host
     *
     * @return $this
     */
    public function setHost($host)
    {
        $this->host = $host;
        return $this;
    }

    /**
     * Gets the host
     *
     * @return string Host
     */
    public function getHost()
    {
        return $this->host;
    }

    /**
     * Sets the user agent of the api client
     *
     * @param string $userAgent the user agent of the api client
     *
     * @return $this
     * @throws \InvalidArgumentException
     */
    public function setUserAgent($userAgent)
    {
        if (!is_string($userAgent)) {
            throw new \InvalidArgumentException('User-agent must be a string.');
        }

        $this->userAgent = $userAgent;
        return $this;
    }

    /**
     * Gets the user agent of the api client
     *
     * @return string user agent
     */
    public function getUserAgent()
    {
        return $this->userAgent;
    }

    /**
     * Sets debug flag
     *
     * @param bool $debug Debug flag
     *
     * @return $this
     */
    public function setDebug($debug)
    {
        $this->debug = $debug;
        return $this;
    }

    /**
     * Gets the debug flag
     *
     * @return bool
     */
    public function getDebug()
    {
        return $this->debug;
    }

    /**
     * Sets the debug file
     *
     * @param string $debugFile Debug file
     *
     * @return $this
     */
    public function setDebugFile($debugFile)
    {
        $this->debugFile = $debugFile;
        return $this;
    }

    /**
     * Gets the debug file
     *
     * @return string
     */
    public function getDebugFile()
    {
        return $this->debugFile;
    }

    /**
     * Sets the temp folder path
     *
     * @param string $tempFolderPath Temp folder path
     *
     * @return $this
     */
    public function setTempFolderPath($tempFolderPath)
    {
        $this->tempFolderPath = $tempFolderPath;
        return $this;
    }

    /**
     * Gets the temp folder path
     *
     * @return string Temp folder path
     */
    public function getTempFolderPath()
    {
        return $this->tempFolderPath;
    }

    /**
     * @param string $method Request method
     * @param string $resourcePath Request path
     * @param array $queryParams Query parameter array
     * @param string $payload Body string
     * @return array Signature headers
     */
    public function buildSignHeaders($method, $resourcePath, $queryParams = null, $payload = null)
    {
        $fullPath = parse_url($this->getHost(), PHP_URL_PATH) . $resourcePath;
        $fmt = "%s\n%s\n%s\n%s\n%s";
        $timestamp = time();
        $hashedPayload = hash("sha512", ($payload !== null) ? $payload : "");
        $signatureString = sprintf(
            $fmt,
            $method,
            $fullPath,
            http_build_query($queryParams),
            $hashedPayload,
            $timestamp
        );
        $signature = hash_hmac("sha512", $signatureString, $this->getSecret());
        return [
            "KEY" => $this->getKey(),
            "SIGN" => $signature,
            "Timestamp" => $timestamp
        ];
    }

    /**
     * Returns an array of host settings
     *
     * @return array host settings
     */
    public function getHostSettings()
    {
        return [
            [
                "url" => "https://api.gateio.ws/api/v4",
                "description" => "Real Trading",
            ],
            [
                "url" => "https://fx-api-testnet.gateio.ws/api/v4",
                "description" => "TestNet Trading",
            ]
        ];
    }

    /**
     * Returns URL based on the index and variables
     *
     * @param int $index array index of the host settings
     * @param array $variables hash of variable and the corresponding value (optional)
     * @return string URL based on host settings
     */
    public function getHostFromSettings($index, $variables = null)
    {
        if (null === $variables) {
            $variables = [];
        }

        $hosts = $this->getHostSettings();

        // check array index out of bound
        if ($index < 0 || $index >= sizeof($hosts)) {
            throw new \InvalidArgumentException("Invalid index $index when selecting the host. Must be less than " . sizeof($hosts));
        }

        $host = $hosts[$index];
        $url = $host["url"];

        // go through variable and assign a value
        foreach ($host["variables"] as $name => $variable) {
            if (array_key_exists($name, $variables)) { // check to see if it's in the variables provided by the user
                if (in_array($variables[$name], $variable["enum_values"], true)) { // check to see if the value is in the enum
                    $url = str_replace("{" . $name . "}", $variables[$name], $url);
                } else {
                    throw new \InvalidArgumentException("The variable `$name` in the host URL has invalid value " . $variables[$name] . ". Must be " . join(',', $variable["enum_values"]) . ".");
                }
            } else {
                // use default value
                $url = str_replace("{" . $name . "}", $variable["default_value"], $url);
            }
        }

        return $url;
    }

    /**
     * @throws ErrorException
     */
    public function __call($name, $arguments)
    {
        $urlArray = explode('__', $name);
        $method = $urlArray[0];

        $url = implode('/', array_slice($urlArray, 1));

        return $this->request($method, $url, $arguments ? $arguments[0] : null);
    }

    private function getUrl($url)
    {
        return $this->getHost() . '/' . $url;
    }

    private function request($method, $url, $params = [])
    {
        $headers = ['Content-Type' => 'application/json'];
        $sign = $this->buildSignHeaders(strtoupper($method), $url, $params);
        $headers = array_merge($headers, $sign);

        $response = Http::withHeaders($headers)->{$method}($this->getUrl($url), $params);
        dd($response);
        $response->onError(function ($callback) {
            $callback->throw();
        });
        return $response->json();
    }
}
