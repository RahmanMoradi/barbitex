<?php

return [
    'route_prefix' => 'country',
    'countries_ban' => ['IR', 'US']
];
