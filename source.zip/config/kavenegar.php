<?php
return [
    'apiKey' => env('KAVENEGAR_API', 'YOUR_KEY'),
    'sender' => env('KAVENEGAR_SENDER', '10006707323323'),
    'debug' => false
];