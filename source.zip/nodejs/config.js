const myConfig = {
    'redis_prefix': 'exvmarket_database_',
    'binance': {
        'apiKey': 'Kv7inMmalyJsTVxSgEg2DFrhJgUww2B39c3HfalDVi9e1o5uEswMHp0Wcouz8rnf',
        'apiSecret': 'mPGdmn6Wjh3P8vP6LJH5lxlGKI4fgY1P2FpUEU35Pnbnm8erzUPS9HgNpnXgX6AD'
    },
    'kucoin': {
        'apiKey': '6124e3802f834a00065b528b',
        'secretKey': 'aeba1969-d38a-4900-9cef-2652aa83a74e',
        'passphrase': 'M.f123654789-*/',
        'environment': 'live'
    }
};
module.exports = {myConfig}
