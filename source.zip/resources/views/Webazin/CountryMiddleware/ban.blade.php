<h1>{{trans('CountryMiddleware::CountryMiddlewareLang.baned')}}</h1>
