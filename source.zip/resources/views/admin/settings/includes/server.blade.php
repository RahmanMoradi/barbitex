<div class="card-body">
    <p class="">
        تنظیمات سرور    </p>
    <div class="col-12 border-primary p-2">
        <div class="table-responsive">
            <livewire:admin.services.services/>
        </div>
    </div>
</div>
