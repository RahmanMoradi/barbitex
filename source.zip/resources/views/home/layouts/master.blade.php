@include('home.layouts.header')
@yield('main')
@include('home.layouts.footer')
