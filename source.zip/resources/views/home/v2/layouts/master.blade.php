@include('home.v2.layouts.header')
@yield('main')
@include('home.v2.layouts.footer')
